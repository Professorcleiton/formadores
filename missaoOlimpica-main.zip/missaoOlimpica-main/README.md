# missaoOlimpica
Desafio da unidade "Funções: criando uma missão sobre Inteligência Artificial"
